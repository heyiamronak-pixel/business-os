# Business OS foundation architecture

## Purpose

Business OS is being built as a multi-tenant, industry-agnostic SaaS. The foundation provides a consistent operating shell while leaving domain workflows and industry modules independent.

This phase intentionally includes:

- A responsive React + Vite web app.
- A shared application shell with route-aware navigation.
- Placeholder routes for the initial product surface.
- A module registry that can grow without hard-coding industry assumptions.
- Existing workspace support for Express, OpenAPI, Drizzle, and PostgreSQL.

This phase intentionally does not include:

- Authentication or local user credentials.
- Business records, demo records, seeds, or analytics values.
- Domain tables or migrations.
- Payment systems, messaging APIs, advertising APIs, or AI provider calls.

## Product boundaries

### Platform layer

The platform layer owns concerns shared by every business:

- Users and authentication provider identity.
- Organizations and membership.
- Roles, permissions, and organization context.
- Feature/module enablement.
- Notifications, audit events, and preferences.
- Tenant isolation and request authorization.

### Core business layer

The core layer owns reusable business concepts:

- Products and inventory.
- Sales and POS transactions.
- Customers.
- Expenses and revenue targets.
- Tasks and reminders.
- Reports and KPI definitions.

Core entities should always belong to an organization. They must not rely on a single industry-specific entity to function.

### Industry module layer

Industry modules add bounded capabilities behind explicit module boundaries. A travel module, for example, can own vehicles, drivers, trips, fuel, maintenance, EMI, and cost-per-kilometre without forcing those concepts into retail or general-purpose tables.

An industry module should declare:

1. Its stable module key and display metadata.
2. The permissions it introduces.
3. The entities and API routes it owns.
4. The navigation entries it contributes.
5. The reports or KPIs it makes available.

## Multi-tenant model direction

The future database should treat `organization_id` as a required tenant boundary on organization-owned records. Server-side authorization must derive the active user and organization context instead of trusting client-provided ownership fields.

The expected relationship direction is:

```text
User
  -> OrganizationMembership
      -> Organization
          -> EnabledModule
          -> Role / Permission assignment
          -> Organization-owned business records
```

Use stable IDs, timestamps, soft deactivation where appropriate, and explicit audit history for permission-sensitive changes.

## Authorization direction

Start with a permission model rather than hard-coding checks for only Owner, Admin, Manager, and Employee. Those roles can be shipped as defaults, while custom roles map to permission keys such as:

```text
sales.read
sales.manage
inventory.read
inventory.manage
team.manage
reports.read
settings.manage
```

The API should enforce permissions. The frontend may hide or disable navigation for clarity, but it must not be the security boundary.

## Frontend structure

The current web app keeps the shell separate from page modules:

- `src/data/modules.ts` is the navigation/module registry.
- `src/components/app-shell.tsx` owns shared navigation and workspace context.
- `src/pages/` owns route-level screens.
- Future feature modules should group their components, API hooks, and page logic by domain instead of expanding the shell.

The current pages are intentionally quiet placeholders. They communicate readiness without manufacturing business state.

## Backend and API direction

When a feature is approved:

1. Define its request and response contract in `lib/api-spec/openapi.yaml`.
2. Regenerate typed client and validation code.
3. Add tenant-aware Drizzle schema in `lib/db/src/schema/`.
4. Add API routes under `artifacts/api-server/src/routes/`.
5. Enforce authentication, organization membership, and permissions server-side.
6. Connect the matching frontend page to real hooks and persistence.

Supabase can be considered later only if the user explicitly chooses it. The workspace is already prepared for PostgreSQL through the existing Drizzle library and should not introduce a second persistence path prematurely.

## Next-phase guardrail

Before implementing any major feature, confirm its domain model, organization boundary, permission surface, API contract, and empty/loading/error states. Build one vertical slice at a time rather than activating every module at once.