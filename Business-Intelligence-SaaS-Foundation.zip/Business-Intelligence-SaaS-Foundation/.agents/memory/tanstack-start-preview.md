---
name: TanStack Start preview timing
description: Interpreting transient pending UI during Replit preview checks for TanStack Start in SPA mode.
---

In this workspace’s TanStack Start SPA preview, a direct route can briefly show the pending fallback while lazy route modules load. Do not diagnose a blank page from one immediate capture; wait for the expected route content, then inspect browser errors.

**Why:** The screenshot capture was faster than module loading; later checks rendered the route cleanly without an application change.

**How to apply:** For route verification, poll for expected page text or inspect after hydration instead of relying on the first preview screenshot.